from decouple import config

BOT_TOKEN = config("BOT_TOKEN")
WEBAPP_URL = config("WEBAPP_URL")
CHANNEL_ID = config("CHANNEL_ID")